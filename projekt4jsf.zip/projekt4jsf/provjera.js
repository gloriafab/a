function slanje() {

    let ime = document.getElementById("ime");
    let prezime = document.getElementById("prezime");
    let grad = document.getElementById("b_grad");
    console.log(`Podaci ${ime.value} - ${prezime.value} - ${grad.value}.`);

    // check boxes
    let chBEls = [];
    chBEls.push(document.getElementById("chb1"));
    chBEls.push(document.getElementById("chb2"));
    chBEls.push(document.getElementById("chb3"));

    // {key:value} -> JSON
    let chb_values = {};
    for(let element of chBEls){
        if(element.checked === true){
            console.log(element.value);
           
            chb_values = element.value;
        }
    }

    // radio buttons
    const radVals = document.querySelectorAll('input[name="rok"]');
    let selectRadioBtn;
    for(const rbv of radVals){
        if(rbv.checked){
            selectRadioBtn = rbv.value;
            break;
        }
    }

    console.log(`Radio button value - selected: ${selectRadioBtn}.`);
    console.log(chb_values);

    localStorage.setItem("chbx_values", JSON.stringify(chb_values));
    localStorage.setItem("rbg1_selection", selectRadioBtn);
    localStorage.setItem("ime", ime.value);
    localStorage.setItem("prezime", prezime.value);
    localStorage.setItem("grad", grad.value);
    window.document.location="rezultati.html";


}

function prikaz() {


    let ime = document.getElementById("ime");
    let prezime = document.getElementById("prezime");
    let grad = document.getElementById("b_grad");
    console.log(`Podaci ${ime.value} - ${prezime.value} - ${grad.value}.`);

    // check boxes
    let chBEls = [];
    chBEls.push(document.getElementById("chb1"));
    chBEls.push(document.getElementById("chb2"));
    chBEls.push(document.getElementById("chb3"));

    // {key:value} -> JSON
    let chb_values = {};
    for(let element of chBEls){
        if(element.checked === true){
            console.log(element.value);
           
            chb_values = element.value;
        }
    }

    // radio buttons
    const radVals = document.querySelectorAll('input[name="rok"]');
    let selectRadioBtn;
    for(const rbv of radVals){
        if(rbv.checked){
            selectRadioBtn = rbv.value;
            break;
        }
    }

    console.log(`Radio button value - selected: ${selectRadioBtn}.`);
    console.log(chb_values);

    localStorage.setItem("chbx_values", JSON.stringify(chb_values));
    localStorage.setItem("rbg1_selection", selectRadioBtn);
    localStorage.setItem("ime", ime.value);
    localStorage.setItem("prezime", prezime.value);
    localStorage.setItem("grad", grad.value);

    let p_predmet = JSON.parse(localStorage.getItem("chbx_values"));
console.log(p_predmet);

let radio_value = localStorage.getItem("rbg1_selection");
console.log(`Odabrani rok: ${radio_value}.`);


let p_ime = localStorage.getItem("ime");
console.log(p_ime);

let p_prezime = localStorage.getItem("prezime");
console.log(p_prezime);

let p_grad = localStorage.getItem("grad");
console.log(p_grad);

let par = document.getElementById("p_podaci");
let prikaz_ime = document.createTextNode("Ime studenta: " + p_ime );
let line_br = document.createElement("br");
let prikaz_prezime = document.createTextNode("Prezime studenta: " + p_prezime );
let line_br2 = document.createElement("br");

let prikaz_grad = document.createTextNode("Grad: " + p_grad );
let line_br3 = document.createElement("br");

let prikaz_predmet = document.createTextNode("Odabrani predmet: " + p_predmet );
let line_br4 = document.createElement("br");

let radValText = document.createTextNode("Odabrani rok: " + radio_value);

par.appendChild(line_br);
par.appendChild(prikaz_ime);
par.appendChild(line_br2);
par.appendChild(prikaz_prezime);
par.appendChild(line_br3);
par.appendChild(prikaz_grad);
par.appendChild(line_br4);
par.appendChild(prikaz_predmet);
par.appendChild(line_br);
par.appendChild(radValText);


}

function promjena_formata() {

    document.querySelectorAll('.table_center').forEach(e => e.classList.replace('table_center', 'oblikovana_tablica'))

}