
let p_predmet = JSON.parse(localStorage.getItem("chbx_values"));
console.log(p_predmet);

let radio_value = localStorage.getItem("rbg1_selection");
console.log(`Odabrani rok: ${radio_value}.`);


let p_ime = localStorage.getItem("ime");
console.log(p_ime);

let p_prezime = localStorage.getItem("prezime");
console.log(p_prezime);

let p_grad = localStorage.getItem("grad");
console.log(p_grad);

let par = document.getElementById("p_formData");
let prikaz_ime = document.createTextNode("Ime studenta: " + p_ime );
let line_br = document.createElement("br");
let prikaz_prezime = document.createTextNode("Prezime studenta: " + p_prezime );
let line_br2 = document.createElement("br");

let prikaz_grad = document.createTextNode("Grad: " + p_grad );
let line_br3 = document.createElement("br");

let prikaz_predmet = document.createTextNode("Odabrani predmet: " + p_predmet );
let line_br4 = document.createElement("br");

let radValText = document.createTextNode("Odabrani rok: " + radio_value);

par.appendChild(line_br);
par.appendChild(prikaz_ime);
par.appendChild(line_br2);
par.appendChild(prikaz_prezime);
par.appendChild(line_br3);
par.appendChild(prikaz_grad);
par.appendChild(line_br4);
par.appendChild(prikaz_predmet);
par.appendChild(line_br);
par.appendChild(radValText);